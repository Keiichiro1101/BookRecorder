package hu.ait.bookrecorder3.googlebookapi

data class ListPrice(
    val amount: Int,
    val currencyCode: String
)