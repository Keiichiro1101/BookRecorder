package hu.ait.bookrecorder3.googlebookapi

data class ReadingModesX(
    val image: Boolean,
    val text: Boolean
)