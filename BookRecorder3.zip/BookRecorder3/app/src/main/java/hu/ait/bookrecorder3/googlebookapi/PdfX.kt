package hu.ait.bookrecorder3.googlebookapi

data class PdfX(
    val acsTokenLink: String,
    val isAvailable: Boolean
)