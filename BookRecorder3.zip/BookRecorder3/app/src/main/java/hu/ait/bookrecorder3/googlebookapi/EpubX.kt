package hu.ait.bookrecorder3.googlebookapi

data class EpubX(
    val acsTokenLink: String,
    val isAvailable: Boolean
)