package hu.ait.bookrecorder3.googlebookapi

data class Pdf(
    val isAvailable: Boolean
)