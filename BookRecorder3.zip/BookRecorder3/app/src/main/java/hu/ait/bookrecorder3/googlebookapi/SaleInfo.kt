package hu.ait.bookrecorder3.googlebookapi

data class SaleInfo(
    val country: String,
    val isEbook: Boolean,
    val saleability: String
)