package hu.ait.bookrecorder3.googlebookapi

data class RetailPriceX(
    val amount: Int,
    val currencyCode: String
)