package hu.ait.bookrecorder3.googlebookapi

data class ImageLinksXX(
    val smallThumbnail: String,
    val thumbnail: String
)