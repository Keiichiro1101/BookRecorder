package hu.ait.bookrecorder3.googlebookapi

data class Epub(
    val isAvailable: Boolean
)