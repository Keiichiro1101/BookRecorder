package hu.ait.bookrecorder3.googlebookapi

data class RetailPrice(
    val amountInMicros: Long,
    val currencyCode: String
)