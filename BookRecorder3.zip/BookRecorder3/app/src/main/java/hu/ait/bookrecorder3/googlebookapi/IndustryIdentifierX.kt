package hu.ait.bookrecorder3.googlebookapi

data class IndustryIdentifierX(
    val identifier: String,
    val type: String
)