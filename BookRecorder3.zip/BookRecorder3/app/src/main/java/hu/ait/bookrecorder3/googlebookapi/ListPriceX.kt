package hu.ait.bookrecorder3.googlebookapi

data class ListPriceX(
    val amountInMicros: Long,
    val currencyCode: String
)