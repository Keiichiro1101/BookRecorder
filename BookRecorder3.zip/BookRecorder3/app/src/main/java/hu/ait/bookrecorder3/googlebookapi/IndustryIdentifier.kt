package hu.ait.bookrecorder3.googlebookapi

data class IndustryIdentifier(
    val identifier: String,
    val type: String
)