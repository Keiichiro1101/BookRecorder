package hu.ait.bookrecorder3.googlebookapi

data class ReadingModes(
    val image: Boolean,
    val text: Boolean
)