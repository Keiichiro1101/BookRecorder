package hu.ait.bookrecorder3.googlebookapi

data class PanelizationSummaryX(
    val containsEpubBubbles: Boolean,
    val containsImageBubbles: Boolean
)